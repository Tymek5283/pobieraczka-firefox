// Tło rozszerzenia (service worker w Chromium, strona tła w Firefoksie): reaguje na nowe logowanie do filmana,
// co pół godziny pyta serwer o stan (znaczek: Authentik, serwer, sesja filmana), przypomina o odnowieniu. Słuchacze rejestrowane synchronicznie na
// starcie skryptu: przeglądarka budzi tło na zdarzenie i musi zastać słuchacza.

import { przejdz } from "./lib/akcje.js";
import { noweLogowanie } from "./lib/ciasteczka.js";
import { poCiasteczkuPanelu } from "./lib/polaczenie.js";
import { api, otworzLogowanieRaz, ustawienia, zapisz } from "./lib/przegladarka.js";
import { ALARM_PONOW, ALARM_STAN_SZYBKO, POWIADOMIENIE_PROBLEMU, sprawdzStan, synchronizuj } from "./lib/synchronizacja.js";

const ALARM_STAN = "stan-sesji";
const CO_ILE_MIN = 30; // stan serwera to odczyt bez zapytań do filmana: tanio, a znaczek szybko pokazuje problem
const ZWLOKA_PO_LOGOWANIU_MS = 4000; // filman ustawia kilka ciasteczek naraz: wysyłamy komplet

const ZWLOKA_PO_PANELU_MS = 3000; // po zalogowaniu do Authentika pośrednik ustawia kilka ciasteczek
// Sprawdzenie po ciasteczku panelu: reguły w lib/polaczenie.js poCiasteczkuPanelu (okno po kliknięciu, raz na minutę).
const ALARM_PO_PANELU = "stan-po-logowaniu-panelu";
const MIN_ALARM_MS = 30000; // Chromium: alarm najwcześniej po 30 s
let zaplanowane = null;
let poPanelu = null;

function wyslijPoLogowaniu() {
  clearTimeout(zaplanowane);
  zaplanowane = setTimeout(() => { synchronizuj({ powod: "logowanie" }).catch(console.error); },
    ZWLOKA_PO_LOGOWANIU_MS);
}

async function przygotuj() {
  await api.alarms.create(ALARM_STAN, { delayInMinutes: 1, periodInMinutes: CO_ILE_MIN });
}

api.runtime.onInstalled.addListener(async ({ reason }) => {
  await przygotuj();
  if (reason === "install") await api.runtime.openOptionsPage();
});
api.runtime.onStartup.addListener(() => { przygotuj().then(sprawdzStan).catch(console.error); });

async function sprawdzPanelTeraz() {
  await zapisz({ ostatnioPoPanelu: Date.now() });
  await sprawdzStan();
}

/** Nowe ciasteczko hosta panelu po kliknięciu „Zaloguj się do panelu”, gdy serwer chciał logowania Authentika:
 * pewnie zalogowano się, więc sprawdzamy serwer (pierwszy raz po 3 s, kolejne najwyżej co minutę). */
async function sprawdzPoLogowaniuPanelu(ciasteczko) {
  const { co, za } = poCiasteczkuPanelu(await ustawienia(), ciasteczko.domain, Date.now());
  if (co === "nic") return;
  if (co === "pozniej") { // odłożone na koniec okna ograniczenia (jeden alarm, kolejne zdarzenia go nadpisują)
    await api.alarms.create(ALARM_PO_PANELU, { when: Date.now() + Math.max(za, MIN_ALARM_MS) });
    return;
  }
  clearTimeout(poPanelu);
  poPanelu = setTimeout(() => { sprawdzPanelTeraz().catch(console.error); }, ZWLOKA_PO_PANELU_MS);
}

api.cookies.onChanged.addListener((zmiana) => {
  if (noweLogowanie(zmiana)) wyslijPoLogowaniu();
  else if (!zmiana.removed) sprawdzPoLogowaniuPanelu(zmiana.cookie).catch(console.error);
});

// Nadanie uprawnień (okienko w Firefoksie zamyka się przy prośbie o nie): stan i wysyłka od razu, bez czekania na alarm.
api.permissions?.onAdded?.addListener(() => { sprawdzStan().catch(console.error); });

api.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_STAN || alarm.name === ALARM_STAN_SZYBKO) sprawdzStan().catch(console.error);
  if (alarm.name === ALARM_PO_PANELU) sprawdzPanelTeraz().catch(console.error);
  if (alarm.name === ALARM_PONOW) synchronizuj({ powod: "ponowienie" }).catch(console.error);
});

api.notifications?.onClicked.addListener((id) => { // bez powiadomień (np. część przeglądarek): sam znaczek
  api.notifications.clear(id);
  if (id === "przypomnienie") otworzLogowanieRaz();
  if (id.startsWith(POWIADOMIENIE_PROBLEMU)) { // problem z lib/stan.js: przejście do naprawy albo ponowne sprawdzenie
    const akcja = id.slice(POWIADOMIENIE_PROBLEMU.length);
    przejdz(akcja).then((przejscie) => przejscie || sprawdzStan()).catch(console.error);
  }
});

// Okienko i ustawienia proszą tło o pracę (tło żyje dłużej niż zamykane okienko).
api.runtime.onMessage.addListener((wiadomosc, _nadawca, odpowiedz) => {
  const praca = wiadomosc?.typ === "wyslij" ? synchronizuj({ wymus: true, powod: "przycisk" })
    : wiadomosc?.typ === "stan" ? sprawdzStan() : null;
  if (!praca) return false;
  praca.then(odpowiedz, (blad) => odpowiedz(`Błąd: ${blad.message}`));
  return true; // odpowiedź asynchroniczna (Chromium)
});
