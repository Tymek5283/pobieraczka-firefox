// Okienko pod ikoną: u góry baner z najważniejszym problemem (Authentik, serwer, sesja filmana…) i przyciskiem naprawy
// (lib/stan.js, ten sam stan co znaczek), niżej podgląd sesji na serwerze (żyje, wygasa, sprawdzona, nowe tokeny,
// skąd, czy z tej przeglądarki), autodiagnostyka (uprawnienia, ciasteczka, połączenie, odpowiedź serwera, ostatnia wysyłka), logowanie jednym
// kliknięciem, ręczna wysyłka, ustawienia.
import { przejdz } from "./lib/akcje.js";
import { token } from "./lib/ciasteczka.js";
import { diagnoza } from "./lib/diagnoza.js";
import { nadajUprawnienia, zbierz } from "./lib/diagnostyka.js";
import { podglad } from "./lib/podglad.js";
import { api, ciasteczkaFilmana, otworzLogowanieRaz, skrot, ustawienia } from "./lib/przegladarka.js";
import { stanOgolny } from "./lib/stan.js";

const $ = (id) => document.getElementById(id);
let adresPanelu = ""; // do prośby o uprawnienia bez await przed nią (Firefox)

async function tokenPrzegladarki() {
  try {
    const tok = token(await ciasteczkaFilmana());
    return tok ? { skrot: await skrot(tok.value), wygasa: tok.expirationDate } : null;
  } catch {
    return null; // brak dostępu do ciasteczek: pokaże to autodiagnostyka
  }
}

function lista(wiersze) {
  return wiersze.flatMap((w) => {
    const dt = document.createElement("dt");
    dt.textContent = w.etykieta;
    const dd = document.createElement("dd");
    dd.textContent = w.wartosc;
    if (w.ton) dd.className = w.ton;
    return [dt, dd];
  });
}

async function sprawdzPonownie() {
  $("baner-opis").textContent = "Sprawdzam serwer…";
  await api.runtime.sendMessage({ typ: "stan" }).catch(() => {});
  pokaz();
}

/** Przycisk naprawy z banera. Uprawnienia: prośba od razu w geście kliknięcia, bez await przed nią (Firefox). */
async function wykonaj(id) {
  if (id === "uprawnienia") {
    const prosba = nadajUprawnienia(adresPanelu);
    $("komunikat").textContent = (await prosba) ? "Uprawnienia nadane." : "Uprawnień nie nadano.";
    return sprawdzPonownie();
  }
  if (id === "ponow") return sprawdzPonownie();
  if (await przejdz(id)) window.close(); // po zalogowaniu (Authentik, filman) rozszerzenie samo sprawdzi i wyśle
}

function przycisk(a, cichy) {
  const b = document.createElement("button");
  b.type = "button";
  b.textContent = a.etykieta;
  b.dataset.akcja = a.id;
  if (cichy) b.className = "cichy";
  b.addEventListener("click", () => { wykonaj(a.id); });
  return b;
}

function baner(stan) {
  $("baner").className = `baner ${stan.poziom}`;
  $("baner-tytul").textContent = stan.tytul;
  $("baner-opis").textContent = stan.opis;
  const akcje = [stan.akcja, ...stan.dodatkowe].filter(Boolean);
  if (stan.poziom !== "ok" && !akcje.some((a) => a.id === "ponow")) akcje.push({ id: "ponow", etykieta: "Sprawdź ponownie" });
  $("baner-akcje").replaceChildren(...akcje.map((a, i) => przycisk(a, i > 0)));
}

async function pokaz() {
  // najpierw wszystkie odczyty, potem jedna podmiana: dwa równoległe pokaz() nie zdublują wierszy
  const [u, przegladarka, fakty] = await Promise.all([ustawienia(), tokenPrzegladarki(), zbierz()]);
  const polaczone = Boolean(u.adres && u.klucz);
  adresPanelu = u.adres || "";
  const wynik = diagnoza(fakty);
  baner(stanOgolny(fakty));
  $("podglad").replaceChildren(...(polaczone ? lista(podglad({ serwer: u.ostatniStan || null, przegladarka,
    potwierdzonySkrot: u.potwierdzonySkrot, potwierdzono: u.potwierdzono })) : []));
  $("diagnoza").replaceChildren(...lista(wynik.wiersze));
  $("diagnoza-podsumowanie").textContent = !wynik.ok ? "Autodiagnostyka: jest problem (szczegóły niżej)"
    : wynik.uwagi ? "Autodiagnostyka: działa, są uwagi" : "Autodiagnostyka: wszystko działa";
  $("diagnoza-podsumowanie").className = wynik.ok ? "dobrze" : "zle";
  if (!wynik.ok) $("diagnoza-blok").open = true;
  $("szczegoly").textContent = u.ostatniBlad ? `Ostatni problem: ${u.ostatniBlad}` : "";
}

$("zaloguj").addEventListener("click", async () => { await otworzLogowanieRaz(); window.close(); });
$("ustawienia").addEventListener("click", () => api.runtime.openOptionsPage());
$("wyslij").addEventListener("click", async () => {
  $("komunikat").textContent = "Wysyłam i sprawdzam na serwerze…";
  $("komunikat").textContent = await api.runtime.sendMessage({ typ: "wyslij" });
  pokaz();
});

pokaz();
api.runtime.sendMessage({ typ: "stan" }).then(pokaz, pokaz); // świeży stan z serwera i wynik autodiagnostyki
