// Strona logowania filmana: zaznacza „zapamiętaj mnie”, bo bez niego filman nie wyda tokenu BKD_REMEMBER i nie ma czego
// wysłać na serwer. Nic poza tym (CAPTCHA, login i hasło zostają człowiekowi). Skrypt treści: bez modułów.
(() => {
  const WZOR = /remember|zapami|pamietaj|pamiętaj/i;
  const opis = (pole) => [pole.name, pole.id, pole.closest("label")?.textContent,
    pole.id ? document.querySelector(`label[for="${CSS.escape(pole.id)}"]`)?.textContent : ""].join(" ");
  // true = pole jest (zaznaczone teraz albo wcześniej): dalej nie patrzymy, więc odznaczenia przez człowieka nie cofamy
  const zaznacz = () => {
    for (const pole of document.querySelectorAll("input[type=checkbox]")) {
      if (!WZOR.test(opis(pole))) continue;
      if (!pole.checked) pole.click(); // jak człowiek: formularz dostaje zdarzenie zmiany
      return true;
    }
    return false;
  };
  if (zaznacz()) return;
  const obserwator = new MutationObserver(() => { if (zaznacz()) obserwator.disconnect(); });
  obserwator.observe(document.body, { childList: true, subtree: true });
  setTimeout(() => obserwator.disconnect(), 30000); // formularz doładowany później; dłużej nie czekamy
})();
