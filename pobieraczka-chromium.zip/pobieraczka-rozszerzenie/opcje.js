// Strona ustawień: połączenie z panelem (ciąg „adres#klucz”), uprawnienie do adresu panelu, pierwsza wysyłka.
import { FILMAN } from "./lib/diagnostyka.js";
import { odczytajPolaczenie, wzorzecHosta } from "./lib/polaczenie.js";
import { api, KLUCZE, ustawienia, zapisz } from "./lib/przegladarka.js";

const $ = (id) => document.getElementById(id);
const komunikat = (tekst, blad = false) => { $("komunikat").textContent = tekst; $("komunikat").className = blad ? "blad" : ""; };

async function pokazObecne() {
  const u = await ustawienia();
  $("obecne").textContent = u.adres ? `Połączono z ${u.adres}.` : "Nie połączono.";
  $("samo-otwieraj").checked = u.samoOtwieraj !== false;
}

$("samo-otwieraj").addEventListener("change", () => zapisz({ samoOtwieraj: $("samo-otwieraj").checked }));

$("polacz").addEventListener("click", async () => {
  let polaczenie;
  try { polaczenie = odczytajPolaczenie($("polaczenie").value); } catch (blad) { komunikat(blad.message, true); return; }
  // w geście użytkownika (wymóg permissions.request): dostęp do panelu i ciasteczek filmana
  const zgoda = await api.permissions.request({ origins: [wzorzecHosta(polaczenie.adres), ...FILMAN] });
  if (!zgoda) { komunikat("Bez dostępu do adresu panelu rozszerzenie nie wyśle sesji.", true); return; }
  await api.storage.local.remove(KLUCZE); // nowe połączenie (np. inny serwer): bez pamięci po poprzednim
  await zapisz({ ...polaczenie });
  $("polaczenie").value = "";
  komunikat("Łączę i sprawdzam sesję…");
  // stan sam wysyła sesję tej przeglądarki (wyczyszczony skrót): druga wysyłka trafiłaby w odstęp konta (409)
  const wynik = await api.runtime.sendMessage({ typ: "stan" });
  if (!wynik?.polaczono) {
    komunikat(`Panel nie odpowiada poprawnie: ${wynik?.blad || wynik || "brak odpowiedzi"}`, true);
    return;
  }
  komunikat(`Połączono. ${wynik.wysylka}`);
  pokazObecne();
});

$("rozlacz").addEventListener("click", async () => {
  await api.storage.local.remove(KLUCZE);
  komunikat("Odłączono. Klucz unieważnisz w panelu (Ustawienia → Rozszerzenie przeglądarki → Odłącz).");
  pokazObecne();
});

pokazObecne();
